#!/usr/bin/python

import psycopg2
from config import config


def create_tables():
    """ create tables in the PostgreSQL database"""
    commands = (

        """
        CREATE TABLE IF NOT EXISTS userList (
                userID text unique NOT NULL check(char_length(userID) = 10),
                phoneNumber text unique check(char_length(phoneNumber) = 10),
                email text unique check(email ~* '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$'),
                age int,
                location text,
                primary key(userID)
            )
        """,
        """
        CREATE TABLE IF NOT EXISTS users(
                userID text unique NOT NULL check(char_length(userID) = 10),
                userName text NOT NULL check(char_length(userName) > 0),
                firstName text check(char_length(firstName) > 0),
                lastName text check(char_length(lastName) > 0),
                primary key(userID),
                foreign  key(userID) references userList(userID)
            )
        """,
        # igtv needs to be fixed
        """
        CREATE TABLE IF NOT EXISTS profile(
                userID text unique NOT NULL check(char_length(UserID) = 10),
                followerCount int check(followerCount > -1),
                followingCount int check(followingCount > -1),
                postCount int check(postCount > -1),
                bio text,
                igtv text,
                profilePicture text,  
                savedID text unique NOT NULL check(char_length(savedID) = 10),
                taggedID text unique NOT NULL check(char_length(taggedID) = 10), 
                profileID text unique NOT NULL check(char_length(profileID) = 10),
                profilePrivate boolean NOT NULL,
                verified boolean NOT NULL,
                notificationID text unique NOT NUll check(char_length(notificationID) = 10),
                primary key(profileID,notificationID,userID,savedID,taggedID),
                foreign  key(userID) references users(userID)                                        
            )
        """,
        """
        CREATE TABLE IF NOT EXISTS aPost(
                postID text unique NOT NULL check(char_length(postID) = 10),
                userID text NOT NULL check(char_length(postID) = 10),
                likeCount int check(likeCount > -1),
                commentID text unique NOT NULL check(char_length(commentID) = 10),
                picture text,
                share text,
                captionID text unique NOT NULL check(char_length(captionID) = 10),
                postViews int check(postViews > -1) ,
                taggedID text NOT NULL check(char_length(taggedID) = 10),
                primary key(commentID,postID,captionID,taggedID),
                foreign key(userID) references profile(userID)
            )
        """,
        """
        CREATE TABLE IF NOT EXISTS notifications(
                yourID text NOT NULL check(char_length(userID) = 10),
                userID text NOT NULL check(char_length(userID) = 10),
                postID text NOT NULL,
                notificationComment text NOT NUll,
                foreign key(userID) references profile(userID),
                foreign key(yourID) references profile(userID)
                    )
                """,

        """
        CREATE TABLE IF NOT EXISTS savedList(
                savedID text NOT NULL check(char_length(savedID) = 10),
                postID text NOT NUll check(char_length(postID) = 10),
                foreign key(savedID) references profile(savedID),
                foreign key(postID) references aPost(postID)
            )
        """,
        """
        CREATE TABLE IF NOT EXISTS taggedList(
                taggedID text NOT NULL check(char_length(taggedID) = 10),
                postID text NOT NUll check(char_length(postID) = 10),
                foreign key(taggedID) references profile(taggedID)
            )
        """,


        """
        CREATE TABLE IF NOT EXISTS hashtagsList(
                hashtagID text unique NOT NUll check(char_length(hashtagID) = 10),
                hashtagCount int,
                primary key(hashtagID)
            )
        """,

        """
        CREATE TABLE IF NOT EXISTS listsOfHashtagsGen(
                hashtagID text NOT NUll check(char_length(hashtagID) = 10),
                hashtag text,
                foreign key(hashtagID) references hashtagsList(hashtagID)
                
                
            )
        """,
        """
         CREATE TABLE IF NOT EXISTS captionList(
                captionID text NOT NULL check(char_length(captionID) = 10),
                caption text,
                hashtagID text NOT NULL check(char_length(hashtagID) = 10),
                foreign key(captionID) references aPost(captionID),
                foreign key(hashtagID) references hashtagsList(hashtagID)
            )
        """,
        """
        CREATE TABLE IF NOT EXISTS comments(
                commentID text NOT NUll check(char_length(commentID) = 10),
                userID text NOt NULL check(char_length(userID) = 10),
                comment text,
                foreign key (commentID) references aPost(commentID),
                foreign key (userID) references profile(userID)
            )
        """,
        """
            CREATE TABLE IF NOT EXISTS following(
                yourID text NOT NUll check(char_length(yourID) = 10),
                userID text  NOT NULL check(char_length(userID) = 10),
                hashtagID text NOT NULL check(char_length(hashtagID) = 10),
                foreign key(yourID) references profile(userID),
                foreign key(userID) references users(userID),
                foreign key(hashtagID) references hashtagsList(hashtagID)
            )
        """,
        """
            CREATE TABLE IF NOT EXISTS followers(
                yourID text NOT NUll check(char_length(yourID) = 10),
                userID text NOT NULL check(char_length(userID) = 10),
                foreign key(yourID) references profile(userID),
                foreign  key(userID) references users(userID)
            )
        """,
        """
            CREATE TABLE IF NOT EXISTS Feed(
                yourID text NOT NULL check(char_length(yourID) = 10),
                feedID text unique NOT NULL check(char_length(feedID) = 10),
                instagramStoriesID text unique NOT NULL check(char_length(instagramStoriesID) = 10),
                whoToFollowID text unique NOT NULL check(char_length(whoToFollowID) = 10),
                
                primary key(WhoToFollowID,instagramStoriesID,feedID),
                foreign key(yourID) references profile(userID)
            )
        """,
        """
            CREATE TABLE IF NOT EXISTS FeedList(
                feedID text  NOT NULL check(char_length(postID) = 10),
                postID text  NOT NULL check(char_length(postID) = 10),
                instagramStoriesID text  NOT NULL check(char_length(InstagramStoriesID) = 10),
                foreign key(postID) references aPost(postID),
                foreign key(feedID) references Feed(feedID),
                foreign key(instagramStoriesID) references Feed(instagramStoriesID)
                
            )
        """,
        """
            CREATE TABLE IF NOT EXISTS whoToFollowList(
                    userID text NOT NULL check(char_length(userID) = 10),
                    whoToFollowID text NOT NULL check(char_length(whoToFollowID) = 10),
                    foreign key(userID) references profile(userID),
                    foreign key(whoToFollowID) references Feed(whoToFollowID)
                    )
                """,

        #There who be a simple algorithm to send yous suggestions on who to follow
        """
            CREATE TABLE IF NOT EXISTS whoToFollowList(
                WhoToFollowID text NOT NULL check(char_length(WhoToFollowID) = 10),
                userID text unique NOT NULL check(char_length(userID) = 10),
                foreign key(WhoToFollowID) references Feed(WhoToFollowID),
                foreign key(userID) references profile(userID)
            )
        """,
        """
                   CREATE TABLE IF NOT EXISTS Explore(
                       WhoToFollowID text unique NOT NULL check(char_length(WhoToFollowID) = 10),
                       userID text unique  NOT NULL check(char_length(userID) = 10),
                       keyword text unique,
                       primary key(WhoToFollowID,userID,keyword),
                       foreign key(userID) references users(userID)
                       )
               """,
        #Instagram pull up all things related to your keyword '@' goes to the persons profile, '#' goes to a hashtag, you can also search by
        #location when your searching it also shows you the number of posts
        """
            CREATE TABLE IF NOT EXISTS searchEngine(
                    keyWord text,
                    keyWordID text unique NOT NULL check(char_length(keyWordID) = 10),
                    primary key(keyWordID),
                    foreign key(keyWord) references Explore(keyWord)
            )
        """,

        """
            CREATE TABLE IF NOT EXISTS searchEngineList(
                    keyWordID text NOT NULL check(char_length(keyWordID) = 10),
                    userID text check(char_length(keyWordID) = 10),
                    location text,
                    hashTagID text,
                    foreign key(keyWordID) references searchEngine(keyWordID),
                    foreign key(hashTagID) references hashtagsList(hashTagID),
                    foreign key(userID) references profile(userID)
            )
        """)
    conn = None
    try:
        # read the connection parameters
        params = config()
        # connect to the PostgreSQL server
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        # create table one by one
        for command in commands:
            cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()


if __name__ == '__main__':
    create_tables()