import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)

    return conn


def create_table(conn, create_table_sql):
    """ create a table from the create_table_sql statement
    :param conn: Connection object
    :param create_table_sql: a CREATE TABLE statement
    :return:
    """
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)


def main():
    database = r"/Users/sean/desktop/InstagramProject/myInstagramDB.db"

    sql_create_names_table1 = """CREATE TABLE IF NOT EXISTS userList(
                                                userID int unique NOT NULL check(userID == 10),
                                                userName text NOT NULL check(userName > 0),
                                                firstName text check(firstName > 0),
                                                lastName text check(lastName > 0),
                                                email text check(email > 2), 
                                                primary key(userid)
                                                );"""
    # email constrant needs to be fixed
    sql_create_names_table2 = """CREATE TABLE IF NOT EXISTS users(
                                                userID int unique NOT NULL check(userID == 10),
                                                phonenumber int check(phonenumber == 10),
                                                primary key(userid),
                                                foreign  key(userid) references userList
                                                );"""
    # igtv constar needs to be fixed
    # tagged needs to be fixed
    # saved needs to be fixed
    # profile picture
    sql_create_names_table3 = """CREATE TABLE IF NOT EXISTS profile(
                                                userID int unique NOT NULL check(UserID == 10),
                                                followerCount int check(followerCount > -1),
                                                followingCount int check(followingCount > -1),
                                                postCount int check(postCount > -1),
                                                bio text,
                                                igtv text,  
                                                saved text,
                                                tagged text,
                                                profileID int unique NOT NULL check(profileID == 10),
                                                profilePicture text,
                                                profileStatus boolean NOT NULL,
                                                notifcationID int unique NOT NUll check(notifcationID == 10),
                                                primary key(profileID,notifcationID),
                                                foreign  key(userid) references users
                                                );"""
    sql_create_names_table4 = """CREATE TABLE IF NOT EXISTS notifcationList(
                                                notifcationID int unique NOT NUll check(notifcationID == 10),
                                                uniqueNotifcationID int unique NOT NUll check(uniqueNotifcationID == 10),
                                                primary key(uniqueNotifcationID),
                                                foreign key(notifcationID) references profile
                                                );"""
    #5,6 or 7
    sql_create_names_table5 = """CREATE TABLE IF NOT EXISTS notifcations(
                                                userID int unique NOT NULL check(Userid == 10),
                                                uniqueNotifcationID int unique NOT NUll check(uniqueNotifcationID == 10),
                                                primary key(uniqueNotifcationID),
                                                foreign key(userID) references 
                                                );"""


    sql_create_names_table6 = """CREATE TABLE IF NOT EXISTS postTProFileList(
                                                profileID int unique NOT NULL check(profileID == 10),
                                                postID int unique NOT NULL check(postID == 10),
                                                primary key(postID),
                                                foreign key(profileID) references profile,
                                                foreign key(postID) references aPost
                                                );"""

    # save needs to be fixed
    # callout needs be fixed linked to a persons profile
    sql_create_names_table7 = """CREATE TABLE IF NOT EXISTS aPost(
                                                likeCount int check(likeCount >-1),
                                                commentID text unique NOT NULL check(commentID == 10),
                                                save text,
                                                picture text,
                                                postID text unique  NOT NULL check(postID == 10),
                                                shareID text unique  NOT NULL check(shareID == 10),
                                                likePost text,
                                                caption text,
                                                hastags text unique,
                                                callOut text unique,
                                                postViews int,
                                                tags text,
                                                primary key(commentID,postID,shareID)
                                                );"""

    sql_create_names_table8 = """CREATE TABLE IF NOT EXISTS Share(
                                                ShareID text unique NOT NULL check(ShareID == 10),
                                                ShareViaMessenger text,
                                                ShareViaEmail text,
                                                ShareViaLink,
                                                foreign key(ShareID) references aPost
                                                );"""
    sql_create_names_table9 = """CREATE TABLE IF NOT EXISTS comments(
                                                commentID text unique NOT NULL check(commentID == 10),
                                                userID int unique NOT NULL check(userID == 10),
                                                comment text,
                                                foreign key (commentID) references aPost,
                                                foreign key (userID) references users
                                                );"""
    sql_create_names_table10 = """CREATE TABLE IF NOT EXISTS Feed(
                                                InstagramStores text,
                                                WhoToFollow text,
                                                postID text unique  NOT NULL check(postID == 10),
                                                foreign key(postID) references aPost
                                                );"""


    # create a database connection
    conn = create_connection(database)

    # create tables
    if conn is not None:
        # create projects table

        # create tasks table
        create_table(conn, sql_create_names_table1)
        create_table(conn, sql_create_names_table2)
        create_table(conn, sql_create_names_table3)
        create_table(conn, sql_create_names_table4)
        create_table(conn, sql_create_names_table5)
        create_table(conn, sql_create_names_table6)
        create_table(conn, sql_create_names_table7)
        create_table(conn, sql_create_names_table8)
        create_table(conn, sql_create_names_table9)
        create_table(conn, sql_create_names_table10)







    else:
        print("Error! cannot create the database connection.")


if __name__ == '__main__':
    main()
