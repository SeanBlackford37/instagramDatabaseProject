#!/usr/bin/python
import psycopg2
import string
import random
from config import config


def create_connection():
    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
    except (Exception, psycopg2.Error) as error:
        if conn:
            print("Failed to insert record into data", error)

    finally:
        # closing database connection.
        if conn:
            cur.close()
            conn.close()
            print("PostgreSQL connection is closed")


def create_task1(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO userList(userID, phoneNumber, email, age, location)
                  VALUES(%s,%s,%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task2(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO users(userID, userName, firstName, lastName)
                  VALUES(%s,%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task3(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO profile(userID, followerCount, followingCount, postCount, bio, igtv, profilePicture, savedID, taggedID, profileID, profilePrivate, notificationID, verified)
                  VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task4(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO notifications(yourID, userID, postID, notificationComment)
                  VALUES(%s,%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task5(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO aPost(postID,userID, likeCount, commentID, picture, share, captionID, postViews, taggedID)
                  VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task6(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO savedList(savedID,postID)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task7(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO hashtagsList(hashtagID,hashtagCount)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task8(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO captionList(captionID,caption,hashTagID)
                  VALUES(%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task9(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO comments(commentID,userID,comment)
                  VALUES(%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task10(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO listsOfHashtagsGen(hashtagID,hashtag)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task11(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO following(yourID,userID,hashtagID)
                  VALUES(%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task12(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO followers(yourID,userID)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task13(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO Feed(yourID,feedID,instagramStoriesID,whoToFollowID)
                  VALUES(%s,%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task14(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO FeedList(feedID,postID,instagramStoriesID)
                  VALUES(%s,%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task15(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO whoToFollowList(WhoToFollowID,userID)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def create_task16(conn, task):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    sql = ''' INSERT INTO taggedList(taggedID,postID)
                  VALUES(%s,%s) '''
    cur = conn.cursor()
    cur.execute(sql, task)
    return cur.lastrowid


def main():
    params = config()
    # connect to the PostgreSQL database
    conn = psycopg2.connect(**params)
    print("populating tables....")
    with conn:
        states = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DC", "DE", "FL", "GA",
                  "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
                  "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
                  "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
                  "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"]
        UserIDSize = 1000
        userIDArray = [None] * UserIDSize
        savedIDArray = [None] * UserIDSize
        taggedIDArray = [None] * UserIDSize
        postCountArray = [None] * UserIDSize
        profileIDArray = [None] * UserIDSize
        notificationIDArray = [None] * (UserIDSize * 2)

        postCountTotal = 0
        print("populating userlist")
        for i in range(0, UserIDSize):
            # userList
            UserIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            userID = UserIDRandom
            userIDArray[i] = UserIDRandom
            phoneNumber = ''.join(random.choices(string.digits, k=10))

            email = ''.join(random.choices(string.ascii_lowercase, k=15)) + "@gmail.com"

            my_list = ['13-17'] * 72 + ['18-29'] * 64 + ['30-49'] * 40 + ['50-64'] * 21 + ['65'] * 10
            my = random.choice(my_list)
            if my == '13-17':
                age = random.randrange(13, 17)
            elif my == '18-29':
                age = random.randrange(18, 29)
            elif my == '30-49':
                age = random.randrange(30, 49)
            elif my == '50-64':
                age = random.randrange(50, 64)
            elif my == '65':
                age = random.randrange(65, 101)

            location = states[random.randrange(0, 49)]
            task_1 = (userID, phoneNumber, email, age, location)
            create_task1(conn, task_1, )
        # users
        print("populating users")
        for i in range(0, UserIDSize):
            userID = userIDArray[i]
            userName = ''.join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase,
                                              k=random.randrange(1, 30)))
            firstName = ''.join(random.choices(string.ascii_lowercase, k=random.randrange(3, 10)))
            lastName = ''.join(random.choices(string.ascii_lowercase, k=random.randrange(4, 15)))
            task_2 = (userID, userName, firstName, lastName)
            create_task2(conn, task_2, )

        # profile
        print("populating profile")
        for i in range(0, UserIDSize):
            userID = userIDArray[i]
            followerCount = random.randrange(0, UserIDSize)
            followingCount = random.randrange(0, UserIDSize)
            postCountRandom = random.randrange(0, 50)
            postCount = postCountRandom
            postCountTotal += postCount
            postCountArray[i] = postCountRandom
            my_list = ['Bio'] * 70 + ['No bio'] * 30
            my = random.choice(my_list)
            if my == 'Bio':
                bio = ''.join(random.choices(string.ascii_lowercase, k=random.randrange(4, 15))) + " " + \
                      ''.join(random.choices(string.ascii_lowercase, k=random.randrange(5, 10)))
            else:
                bio = "No Bio Available"
            igtv = "Video.mp4"
            profilePicture = "profilePicture.mp4"
            savedIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            savedID = savedIDRandom
            savedIDArray[i] = savedIDRandom
            taggedIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            taggedID = taggedIDRandom
            taggedIDArray[i] = taggedIDRandom
            profileIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            profileID = profileIDRandom
            profileIDArray[i] = profileIDRandom
            my_list = ['Private'] * 40 + ['Public'] * 60
            my = random.choice(my_list)
            if my == 'Private':
                profilePrivate = True
            else:
                profilePrivate = False
            noticationIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            notifcationID = noticationIDRandom
            notificationIDArray[i] = noticationIDRandom
            my_list = ['Verified'] * 5 + ['Not Verified'] * 95
            my = random.choice(my_list)
            if my == 'Verified':
                verified = True
                profilePrivate = False
            else:
                verified = False
            task_3 = (
                userID, followerCount, followingCount, postCount, bio, igtv, profilePicture, savedID, taggedID,profileID, profilePrivate, notifcationID, verified)
            create_task3(conn, task_3, )

        # aPost
        print("populating userPost's")
        postIDArray = [None] * postCountTotal
        captionIDArray = [None] * postCountTotal
        commentIDArray = [None] * postCountTotal

        count = 0
        for i in range(0, UserIDSize):
            userID = userIDArray[i]
            postCount = postCountArray[i]
            for j in range(0, postCount):
                postIDrandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
                postIDArray[count] = postIDrandom
                postID = postIDrandom
                likeCount = random.randrange(0, 1000)
                commentIDrandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
                commentIDArray[count] = commentIDrandom
                commentID = commentIDrandom
                picture = "picture.jpg"
                share = "Share to messenger or Share via email or copy link"
                captionIDRandom = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
                captionIDArray[count] = captionIDRandom
                captionID = captionIDRandom
                postViews = random.randrange(0, 1000)
                taggedID = taggedIDArray[random.randrange(0, UserIDSize)]
                count += 1
                task_5 = (postID, userID, likeCount, commentID, picture, share, captionID, postViews, taggedID)
                create_task5(conn, task_5, )

        # taggedList
        print("populating tags")
        for i in range(0, UserIDSize):
            taggedID = taggedIDArray[i]
            for j in range(0, random.randrange(1, 5)):
                postID = postIDArray[random.randrange(0, UserIDSize)]
                task_16 = (taggedID, postID)
                create_task16(conn, task_16)

        # notications
        print("populating notications")
        for i in range(0, (UserIDSize * 2)):
            yourID = userIDArray[random.randrange(0, UserIDSize)]
            userID = userIDArray[random.randrange(0, UserIDSize)]
            postID = postIDArray[random.randrange(0, postCountTotal)]

            if yourID == userID:
                notificationComment = "Enjoy Using Instagram"
            else:
                my_list = ['liked your post'] * 60 + ['followed you'] * 30
                my = random.choice(my_list)
                if my == 'liked your post':
                    notificationComment = userID + " liked your post " + postID

                else:
                    notificationComment = userID + " followed you"
            task_4 = (yourID, userID, postID, notificationComment)
            create_task4(conn, task_4, )

        # savedList
        print("populating saved")
        for i in range(0, UserIDSize):
            savedID = savedIDArray[i]
            for j in range(0, 3):
                postID = postIDArray[random.randrange(0, postCountTotal)]
                task_6 = (savedID, postID)
                create_task6(conn, task_6, )

        # hashtagList
        print("populating hashtaglist")
        hashTagIDarray = [None] * postCountTotal
        for i in range(0, postCountTotal):
            hashTagID = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
            hashTagIDarray[i] = hashTagID
            hashtagcount = 0
            task_7 = (hashTagID,hashtagcount)
            create_task7(conn, task_7, )

        # listOfHashtagsGen
        print("populating hashtags")
        for i in range(0, postCountTotal):
            hashTagID = hashTagIDarray[i]
            for j in range(0, random.randrange(1, 4)):
                hashTagArray = ['love', 'instagood', 'phontooftheday', 'fashion', 'beautiful', 'happy', 'cute',
                                'tbt',
                                'like4like', 'followme', 'picoftheday', 'follow', 'me', 'selfie', 'summer', 'art',
                                'instadaily', 'friends', 'repost', 'nature', 'girl', 'fun', 'style', 'smile',
                                'food']

                hashTag = '#' + hashTagArray[random.randrange(0, 25)]
                task_10 = (hashTagID, hashTag)
                create_task10(conn, task_10, )

        # captionList
        print("populating captions")
        for i in range(0, postCountTotal):
            captionID = captionIDArray[i]
            caption = ''.join(random.choices(string.ascii_lowercase, k=10)) + '\n' + \
                      ''.join(random.choices(string.ascii_lowercase, k=15))
            hashTagID = hashTagIDarray[i]
            task_8 = (captionID, caption, hashTagID)
            create_task8(conn, task_8)

        # comments
        print("populating comments")
        for i in range(0, postCountTotal):
            commentID = commentIDArray[i]
            for j in range(0, random.randrange(1, 10)):
                comment = ''.join(random.choices(string.ascii_lowercase, k=10)) + '\n' + \
                          ''.join(random.choices(string.ascii_lowercase, k=15))
                userID = userIDArray[random.randrange(0, UserIDSize)]
                task_9 = (commentID, userID, comment)
                create_task9(conn, task_9)

        # following
        print("populating following")
        for i in range(0, UserIDSize):
            yourID = userIDArray[i]
            hashTagID = hashTagIDarray[i]
            for j in range(0, random.randrange(1, UserIDSize / 2)):
                userID = userIDArray[random.randrange(1, UserIDSize)]
                while userID == yourID:
                    userID = userIDArray[random.randrange(1, UserIDSize)]
                task_11 = (yourID, userID, hashTagID)
                create_task11(conn, task_11)

        # followers
        print("populating followers")
        for i in range(0, UserIDSize):
            yourID = userIDArray[i]

            for j in range(0, random.randrange(1, UserIDSize / 2)):
                userID = userIDArray[random.randrange(1, UserIDSize)]
                while userID == yourID:
                    userID = userIDArray[random.randrange(1, UserIDSize)]
                task_12 = (yourID, userID)
                create_task12(conn, task_12)
        # feed
        print("populating feed")
        instagramStoriesIDarray = [None] * UserIDSize
        whoToFollowIDarray = [None] * UserIDSize
        feedIDarry = [None] * UserIDSize
        for i in range(0, UserIDSize):
            yourID = userIDArray[i]
            feedID = ''.join(random.choices(string.ascii_lowercase, k=10))
            feedIDarry[i] = feedID
            instagramStoriesID = ''.join(random.choices(string.ascii_lowercase, k=10))
            instagramStoriesIDarray[i] = instagramStoriesID
            whoToFollowID = ''.join(random.choices(string.ascii_lowercase, k=10))
            whoToFollowIDarray[i] = whoToFollowID
            task_13 = (yourID, feedID, instagramStoriesID, whoToFollowID)
            create_task13(conn, task_13)

        # feedList
        print("populating feedlist")
        for i in range(0, UserIDSize):
            feedID = feedIDarry[i]
            for j in range(0, random.randrange(5, 20)):
                postID = postIDArray[random.randrange(0, UserIDSize)]
                instagramStoriesID = instagramStoriesIDarray[random.randrange(0, UserIDSize)]
                task_14 = (feedID, postID, instagramStoriesID)
                create_task14(conn, task_14)
        # whoToFollowList
        print("populating whoToFollowList")
        for i in range(0, UserIDSize):
            whoToFollowID = whoToFollowIDarray[i]
            for j in range(0, 10):
                userID = userIDArray[random.randrange(0, UserIDSize)]
                task_15 = (whoToFollowID, userID)
                create_task15(conn, task_15)

    print("tables have been populated")


if __name__ == '__main__':
    main()
